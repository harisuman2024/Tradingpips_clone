// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking on a link
    const navLinkItems = document.querySelectorAll('.nav-links a');
    navLinkItems.forEach(link => {
        link.addEventListener('click', function() {
            navLinks.classList.remove('active');
            mobileMenuBtn.classList.remove('active');
        });
    });
    
    // Pricing Tabs Functionality
    const tabBtns = document.querySelectorAll('.tab-btn');
    const planBtns = document.querySelectorAll('.plan-btn');
    const sizeBtns = document.querySelectorAll('.size-btn');
    
    // Tab buttons
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Plan buttons
    planBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            planBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Size buttons
    sizeBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            sizeBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Update pricing display based on selected size
            updatePricing(this.textContent);
        });
    });
    
    // Statistics Carousel
    const statsTrack = document.getElementById('statsTrack');
    const statsPrev = document.getElementById('statsPrev');
    const statsNext = document.getElementById('statsNext');
    
    if (statsTrack && statsPrev && statsNext) {
        let currentStatsIndex = 0;
        const statsItems = statsTrack.children;
        const statsItemWidth = 224; // 200px width + 24px gap
        const maxStatsIndex = Math.max(0, statsItems.length - 3);
        
        function updateStatsCarousel() {
            const translateX = -currentStatsIndex * statsItemWidth;
            statsTrack.style.transform = `translateX(${translateX}px)`;
        }
        
        statsPrev.addEventListener('click', function() {
            currentStatsIndex = Math.max(0, currentStatsIndex - 1);
            updateStatsCarousel();
        });
        
        statsNext.addEventListener('click', function() {
            currentStatsIndex = Math.min(maxStatsIndex, currentStatsIndex + 1);
            updateStatsCarousel();
        });
        
        // Auto-scroll stats carousel
        setInterval(function() {
            currentStatsIndex = currentStatsIndex >= maxStatsIndex ? 0 : currentStatsIndex + 1;
            updateStatsCarousel();
        }, 3000);
    }
    
    // Platform Carousel Auto-scroll
    const platformTrack = document.getElementById('platformTrack');
    if (platformTrack) {
        // Clone platform items for seamless loop
        const platformItems = Array.from(platformTrack.children);
        platformItems.forEach(item => {
            const clone = item.cloneNode(true);
            platformTrack.appendChild(clone);
        });
    }
    
    // Newsletter Form
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            if (email) {
                // Simulate newsletter subscription
                alert('Thank you for subscribing to our newsletter!');
                this.querySelector('input[type="email"]').value = '';
            }
        });
    }
    
    // Smooth Scrolling for Navigation Links
    const smoothScrollLinks = document.querySelectorAll('a[href^="#"]');
    smoothScrollLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.header').offsetHeight + 20;
                const targetPosition = targetElement.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Intersection Observer for Animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll('.feature-card, .stat-item, .testimonial-item, .community-card');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
    
    // Update Pricing Function
    function updatePricing(size) {
        const priceMap = {
            '$5K': '$89',
            '$10K': '$149',
            '$25K': '$249',
            '$50K': '$389',
            '$100K': '$529'
        };
        
        const accountSizeMap = {
            '$5K': '5k',
            '$10K': '10k',
            '$25K': '25k',
            '$50K': '50k',
            '$100K': '100k'
        };
        
        const priceElement = document.querySelector('.price');
        const accountSizeElement = document.querySelector('.account-size');
        
        if (priceElement && priceMap[size]) {
            priceElement.textContent = `Price: ${priceMap[size]}`;
        }
        
        if (accountSizeElement && accountSizeMap[size]) {
            accountSizeElement.textContent = `Account size: ${accountSizeMap[size]}`;
        }
    }
    
    // Testimonials Carousel (if needed)
    const testimonialsGrid = document.querySelector('.testimonials-grid');
    if (testimonialsGrid) {
        // Add hover effects to testimonial items
        const testimonialItems = document.querySelectorAll('.testimonial-item');
        testimonialItems.forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.05)';
                this.style.transition = 'transform 0.3s ease';
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        });
    }
    
    // Add loading animation
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
    });
    
    // Parallax effect for hero section
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const hero = document.querySelector('.hero');
        
        if (hero) {
            const rate = scrolled * -0.5;
            hero.style.transform = `translateY(${rate}px)`;
        }
    });
    
    // Add click effects to buttons
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Create ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Feature cards hover effect
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.background = 'rgba(99, 102, 241, 0.1)';
            this.style.borderColor = 'rgba(99, 102, 241, 0.3)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.background = 'rgba(255, 255, 255, 0.05)';
            this.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        });
    });
    
    // Add typing effect to hero title (optional)
    const heroTitle = document.querySelector('.hero-title');
    if (heroTitle) {
        const text = heroTitle.innerHTML;
        heroTitle.innerHTML = '';
        let i = 0;
        
        function typeWriter() {
            if (i < text.length) {
                heroTitle.innerHTML += text.charAt(i);
                i++;
                setTimeout(typeWriter, 50);
            }
        }
        
        // Uncomment to enable typing effect
        // setTimeout(typeWriter, 1000);
        
        // For now, just show the text immediately
        heroTitle.innerHTML = text;
    }
    
    // Add scroll indicator
    const scrollIndicator = document.createElement('div');
    scrollIndicator.className = 'scroll-indicator';
    scrollIndicator.innerHTML = '↓';
    scrollIndicator.style.cssText = `
        position: fixed;
        bottom: 30px;
        left: 50%;
        transform: translateX(-50%);
        color: #6366f1;
        font-size: 24px;
        animation: bounce 2s infinite;
        cursor: pointer;
        z-index: 1000;
    `;
    
    // Add bounce animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); }
            40% { transform: translateX(-50%) translateY(-10px); }
            60% { transform: translateX(-50%) translateY(-5px); }
        }
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: ripple-animation 0.6s linear;
            pointer-events: none;
        }
        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(scrollIndicator);
    
    scrollIndicator.addEventListener('click', function() {
        document.querySelector('.features').scrollIntoView({ behavior: 'smooth' });
    });
    
    // Hide scroll indicator when scrolled
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 100) {
            scrollIndicator.style.opacity = '0';
        } else {
            scrollIndicator.style.opacity = '1';
        }
    });
    
});

// Error handling
window.addEventListener('error', function(e) {
    console.log('An error occurred:', e.error);
});

// Performance optimization
if ('requestIdleCallback' in window) {
    requestIdleCallback(function() {
        // Preload images
        const images = [
            'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
            'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150',
            'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
            'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150'
        ];
        
        images.forEach(src => {
            const img = new Image();
            img.src = src;
        });
    });
}
